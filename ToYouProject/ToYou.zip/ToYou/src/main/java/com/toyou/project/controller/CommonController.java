package com.toyou.project.controller;

import org.springframework.stereotype.Controller;

@Controller
public class CommonController {
	
}
