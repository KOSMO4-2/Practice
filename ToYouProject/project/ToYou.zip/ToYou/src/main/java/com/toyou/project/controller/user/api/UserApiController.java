package com.toyou.project.controller.user.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.toyou.project.dto.ResponseDTO;
import com.toyou.project.model.UserVO;
import com.toyou.project.service.user.UserService;

@RestController
public class UserApiController {

	@Autowired 
	private UserService userService;
	
	@Autowired
	private BCryptPasswordEncoder encode;
	
	
	@PostMapping("/auth/joinProc")
	public ResponseDTO<Integer> userJoin(@RequestBody UserVO vo){ 
		userService.userJoin(vo);
		return new ResponseDTO<Integer>(HttpStatus.OK.value(),1);
	}
}
