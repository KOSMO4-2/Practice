package com.toyou.project.controller.community;

public class CommunityController {

}
