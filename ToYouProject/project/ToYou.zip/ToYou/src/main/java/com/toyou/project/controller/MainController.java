package com.toyou.project.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;


@Controller
public class MainController {
	
	

	// 
	@GetMapping({"/",""})
	public String home() {
		
		return "index";
	}
	
	
	@GetMapping("/auth/searchChannel")
	public String searchChannel() {
		return "index";
	}
	
	@GetMapping("/auth/trend")
	public String trend() {
		return "index";
	}
	
	@GetMapping("/auth/community")
	public String community() {
		return "community";
	}
	
	@GetMapping("/auth/magazine")
	public String magazine() {
		return "index2";
	}
	
	@GetMapping("/payinfo")
	public String payinfo() {
		return "payinfo";
	}
	
	@GetMapping("auth/loginFrom2")
	public String login() {
		return "login/loginFrom";
	}
	
	@GetMapping("mypage")
	public String myPage() {
		return "mypage";
	}
	
	
}
