package com.toyou.project.service.user;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.toyou.project.dao.user.UserDAO;
import com.toyou.project.model.UserVO;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDAO userDAO;
	
	@Autowired
	private BCryptPasswordEncoder encoder;
	
	
	// 수정할거
	@Override
	@Transactional
	public int userJoin(UserVO vo){
		String rawPassword = vo.getUser_password(); 
		String encPassword = encoder.encode(rawPassword);
		vo.setUser_password(encPassword);
		System.out.println(vo.getUser_password());
		userDAO.save(vo);
		return 0;
	}

}
