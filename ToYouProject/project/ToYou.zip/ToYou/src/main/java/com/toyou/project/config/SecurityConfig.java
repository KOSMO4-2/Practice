package com.toyou.project.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

//Bean 등록 : 스프링 컨테이너에서 객체를 관리할 수 있게 하는 것
@Configuration // 빈 등록(ioc관리)
@EnableWebSecurity // 시큐리티 필터를 등록 = 활성화 된 스프링 시큐리티가 해당 파일에서 설정을 할 수 있게 하는 @
@EnableGlobalMethodSecurity(prePostEnabled = true) // 특정 주소로 접근을 하면 권한 및 인증을 미리 체크하겠다는 뜻
public class SecurityConfig extends WebSecurityConfigurerAdapter{

	// 패스워드 해쉬 암호화
	@Bean	// Bean 등록
	public BCryptPasswordEncoder encodePW() {
		return new BCryptPasswordEncoder();
	}
	
	// 시큐리티가 대신 로그인해줄때 password 를 가로챈다.
	// 해당 password 가 어떤 규칙으로 해쉬가 되어 회원가입이 되어있는지 알아야
	// 같은 해쉬로 암호화해서 DB에 있는 해쉬랑 비교가능함
	
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception{
		auth.userDetailsService(null).passwordEncoder(encodePW());
	}
	
	
	
	// URL 접근권한 설정
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http
		.authorizeRequests() // 요청이 들어오면
			.antMatchers("/","/auth/**","/js/**","/css/**","/image/**") // 제외할 페이지 설정
			.permitAll()
			.anyRequest()	// 위 주소의 요청이 아니면
			.authenticated()	// 모두 인증이 되어야한다는 명령어
		.and() // 그 후 보낼 곳 설정
			.formLogin() // 로그인 시킬거니깐
			.loginPage("/auth/loginForm") // 로그인 페이지로 이동
			.loginProcessingUrl("/auth/loginProc")
			.defaultSuccessUrl("/");
	}
	
}
