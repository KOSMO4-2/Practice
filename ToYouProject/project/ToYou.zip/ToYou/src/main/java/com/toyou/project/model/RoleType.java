package com.toyou.project.model;

public enum RoleType {
USER,ADMIN
}
